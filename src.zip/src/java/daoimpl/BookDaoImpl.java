package daoimpl;

public class BookDaoImpl {
    
}
