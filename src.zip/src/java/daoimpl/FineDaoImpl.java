package daoimpl;

public class FineDaoImpl {
    
}
