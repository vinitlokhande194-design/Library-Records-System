package daoimpl;

public class BookIssueDaoImpl {
    
}
