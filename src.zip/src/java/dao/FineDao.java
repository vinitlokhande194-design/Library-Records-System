package dao;

import java.util.List;
import model.Fine;

public interface FineDao {

    void addFine(Fine fine);

    void updateFine(Fine fine);

    Fine getFineById(int fineId);

    List<Fine> getAllFines();
}
