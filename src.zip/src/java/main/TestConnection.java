package main;

import java.sql.*;
import util.DBConnection;

public class TestConnection {

    public static void main(String[] args) throws Exception {

        Connection con = DBConnection.getConnection();

        if (con != null) {
            System.out.println("Database Connected Successfully!");
        } else {
            System.out.println("Connection Failed!");
        }
    }
}
