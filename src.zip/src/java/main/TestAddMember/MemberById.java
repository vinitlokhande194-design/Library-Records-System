package main.TestAddMember;

import dao.MemberDao;
import daoimpl.MemberDaoImpl;
import model.Member;

public class MemberById {

    public static void main(String[] args) {

        try {

            MemberDao memberDao = new MemberDaoImpl();

            Member member = memberDao.getMemberById(4);

            if (member != null) {

                System.out.println("ID : " + member.getMemberId());
                System.out.println("Name : " + member.getMemberName());
                System.out.println("Email : " + member.getEmail());
                System.out.println("Phone : " + member.getPhone());
                System.out.println("Type : " + member.getMemberType());

            } else {

                System.out.println("Member Not Found");
            }

        } catch (Exception e) {
            System.out.println("***********************************************");
        }
    }
}
