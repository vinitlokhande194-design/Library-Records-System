package main.TestAddMember;

import dao.MemberDao;
import daoimpl.MemberDaoImpl;

public class DeleteMember {

    public static void main(String[] args) {

        try {

            MemberDao memberDao = new MemberDaoImpl();

            memberDao.deleteMember(3);

        } catch (Exception e) {
            System.out.println("***********************************************");
        }
    }
}
