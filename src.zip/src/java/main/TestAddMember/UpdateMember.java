package main.TestAddMember;

import dao.MemberDao;
import daoimpl.MemberDaoImpl;
import java.sql.Date;
import model.Member;
import model.StudentMember;

public class UpdateMember {

    public static void main(String[] args) {

        try {

            MemberDao memberDao = new MemberDaoImpl();

            Member member = new StudentMember();

            member.setMemberId(5);
            member.setMemberName("Rahul Updated");
            member.setEmail("rahulnew@gmail.com");
            member.setPhone("8888888888");
            member.setMemberType("STUDENT");
            member.setRegistrationDate(
                    new Date(System.currentTimeMillis()));

            memberDao.updateMember(member);

        } catch (Exception e) {
            System.out.println("***********************************************");
        }
    }
}
