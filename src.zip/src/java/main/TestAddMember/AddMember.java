package main.TestAddMember;

import dao.MemberDao;
import daoimpl.MemberDaoImpl;
import java.sql.Date;
import model.Member;
import model.StudentMember;

public class AddMember {

    public static void main(String[] args) {

        try {

            MemberDao memberDao = new MemberDaoImpl();

            Member member = new StudentMember();

            member.setMemberName("Vinit Sharma");
            member.setEmail("rahul@gmail.com");
            member.setPhone("9876543210");
            member.setMemberType("FACULTY");
            member.setRegistrationDate(new Date(System.currentTimeMillis()));

            memberDao.addMember(member);

        } catch (Exception e) {
            System.out.println("***********************************************");
        }
    }
}
