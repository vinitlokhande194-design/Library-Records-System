package main.TestAddMember;

import dao.MemberDao;
import daoimpl.MemberDaoImpl;
import java.util.List;
import model.Member;

public class getAllMembers {

    public static void main(String[] args) {

        try {

            MemberDao memberDao = new MemberDaoImpl();

            List<Member> members
                    = memberDao.getAllMembers();

            for (Member member : members) {

                System.out.println("--------------------");
                System.out.println("ID : " + member.getMemberId());
                System.out.println("Name : " + member.getMemberName());
                System.out.println("Email : " + member.getEmail());
                System.out.println("Phone : " + member.getPhone());
                System.out.println("Type : " + member.getMemberType());
            }

        } catch (Exception e) {
            System.out.println("***********************************************");
        }
    }
}
